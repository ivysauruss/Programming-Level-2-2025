//
//  Pick_a_PalApp.swift
//  Pick-a-Pal
//
//  Created by Tim Ubial on 2025-05-05.
//

import SwiftUI

@main
struct Pick_a_PalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
