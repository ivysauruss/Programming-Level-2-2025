//
//  SimpleCalculatorApp.swift
//  SimpleCalculator
//
//  Created by Alissa Xu - 697 on 2025-02-18.
//

import SwiftUI

@main
struct SimpleCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
